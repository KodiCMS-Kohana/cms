<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Messages' => 'Сообщения',
	'Send message' => 'Отправить сообщение',
	'You dont have messages' => 'У вас нет сообщений',
	'Message title' => 'Тема сообщения',
	'Message to' => 'Кому',
	'Message author' => 'Отправитель',
	'Date created' => 'Дата получения',
	'View messages list' => 'Видеть раздел',
	'Send messages' => 'Отправлять сообщения',
	'Read own messages' => 'Читать свои сообщения',
	'Delete own messages' => 'Удалять свои сообщения',
	'Subject' => 'Тема',
	'Answer' => 'Ответ'
);
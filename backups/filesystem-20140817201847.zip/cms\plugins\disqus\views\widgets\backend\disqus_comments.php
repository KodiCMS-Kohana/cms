<div class="panel-body">
	<?php echo HTML::anchor('http://help.disqus.com/customer/portal/articles/472098-javascript-configuration-variables', 'Disqus FAQ', array(
		'class' => 'popup fancybox.iframe btn btn-info'
	)); ?>
</div>
<?php defined('SYSPATH') or die('No direct access allowed.');

Plugin::factory('page_fields', array(
	'title' => 'Page fields',
	'description' => '',
))->register();
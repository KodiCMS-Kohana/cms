<?php echo View::factory('widgets/backend/blocks/section', array(
	'widget' => $widget
)); ?>

<?php if( $widget->ds_id == 0 ): ?>
<div class="panel-body">
	<div class="alert alert-warning">
		<?php echo UI::icon('lightbulb-o'); ?> <?php echo __('You need select hybrid section'); ?>
	</div>
</div>
<?php else: ?>
<?php echo View::factory('widgets/backend/blocks/tag_fields', array(
	'widget' => $widget
)); ?>

<?php echo View::factory('widgets/backend/tags_cloud', array(
	'widget' => $widget
)); ?>
<?php endif; ?>

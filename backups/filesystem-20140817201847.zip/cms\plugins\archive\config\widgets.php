<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	__('Archive') => array(
		'archive_day' => __('Archive by day'),
		'archive_month' => __('Archive by month'),
		'archive_year' => __('Archive by year'),
		'archive_hl' => __('Archive headline'),
	)
);
<?php defined('SYSPATH') or die('No direct access allowed.');

class Behavior_PageNotFound extends Behavior_Abstract
{
	public function execute()
	{
	}
}
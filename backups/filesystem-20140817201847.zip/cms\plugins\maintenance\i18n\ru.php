<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Maintenance mode' => ' Режим обслуживания',
	'Enable maintenance mode' => 'Включить'
);
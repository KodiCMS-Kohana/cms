<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'hybrid_docs' => array(),
);
<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Access denied for :period minutes.' => 'Доступ запрещен на :period минут.',
	'Period of blocking (min.)' => 'Период блокировки пользователя (мин.)',
	'Limit of user attempts' => 'Лимит попыток',
	'Limit of user attempts for showing captcha' => 'Лимит попыток до показа капчи',
	'Blocked IP' => 'Заблокированные IP',
	'IP settings' => 'Настройки IP'
);
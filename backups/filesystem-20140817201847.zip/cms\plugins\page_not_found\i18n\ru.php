<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Page not found' => 'Страница не найдена',
);
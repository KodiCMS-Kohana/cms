<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	__('Datasource') => array(
		'hybrid_document' => __('Hybrid Document'),
		'hybrid_headline' => __('Hybrid Headline'),
		'hybrid_creator' => __('Hybrid Document creator'),
		'hybrid_tags' => __('Hybrid tags'),
		'hybrid_editor' => __('Hybrid Document editor'),
	)
);
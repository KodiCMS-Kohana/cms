<h1><?php echo $header; ?></h1>

<?php echo debug::Vars($docs); ?>
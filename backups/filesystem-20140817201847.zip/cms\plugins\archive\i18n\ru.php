<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'Archive' => 'Архив',
	'Archive by day' => 'Архив за день',
	'Archive by month' => 'Архив за месяц',
	'Archive by year' => 'Архив за год',
	'Archive headline' => 'Список архивных документов',
	'Public link' => 'Публичная ссылка',
	'Archive day index' => 'Архив по дням',
	'Archive month index' => 'Архив по месяцам',
	'Archive year index' => 'Архив по годам'
);
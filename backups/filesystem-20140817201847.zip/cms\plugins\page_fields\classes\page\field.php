<?php defined('SYSPATH') or die('No direct access allowed.');

class Page_Field extends KodiCMS_Page_Field{}
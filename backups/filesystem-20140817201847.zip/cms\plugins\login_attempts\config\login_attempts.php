<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'period' => 30,
	'max_attempts' => 5,
	'max_attempts_for_captcha' => 3
);
<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'types' => array(
		'hybrid' => __('Hybrid')
	)
);
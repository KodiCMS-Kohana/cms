<div class="form-group">
	<label class="control-label" for="primitive_default"><?php echo __( 'Default value' ); ?></label>
	<div class="controls">
		<?php echo Form::input( 'default', $field->default, array(
			'class' => 'input-xxlarge'
		) ); ?>
	</div>
</div>
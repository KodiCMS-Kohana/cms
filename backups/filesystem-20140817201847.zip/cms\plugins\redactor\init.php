<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

Plugin::factory('redactor', array(
	'title' => 'Redactor',
	'description' => 'Create word-processed text on the web using a reliable, fast and unbelievably beautiful editor.',
))->register();
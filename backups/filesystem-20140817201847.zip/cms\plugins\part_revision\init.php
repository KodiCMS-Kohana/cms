<?php defined('SYSPATH') or die('No direct access allowed.');

Plugin::factory('part_revision', array(
	'title' => 'Revision of parts',
))->register();
<?php defined('SYSPATH') or die('No direct access allowed.');

Plugin::factory('hybrid', array(
	'title' => 'Hybrid Datasource',
))->register();

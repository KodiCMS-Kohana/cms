<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'folder.is_dir' => 'Must be a directory',
);